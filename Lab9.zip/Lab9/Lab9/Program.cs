﻿using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        string path = "C:\\Users\\SinguL9riti\\Desktop\\ООП\\Lab9\\text.txt"; 
        Console.WriteLine(File.ReadAllText(path)
                                  .Split(new[] { ' ', '\t', '\n', '\r', '.', ',', ';', ':', '!', '?' }, StringSplitOptions.RemoveEmptyEntries)
                                  .Select(word => word.ToLower())
                                  .Where(word => word.Length > 3)
                                  .Distinct()
                                  .Count());
    }
}
